--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-1.pgdg19.04+1)
-- Dumped by pg_dump version 11.5 (Ubuntu 11.5-1.pgdg19.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE videocards_shop;
--
-- Name: videocards_shop; Type: DATABASE; Schema: -; Owner: rlllok
--

CREATE DATABASE videocards_shop WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE videocards_shop OWNER TO rlllok;

\connect videocards_shop

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying NOT NULL,
    account_balance numeric DEFAULT 0 NOT NULL
);


ALTER TABLE public.customers OWNER TO rlllok;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: rlllok
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_id_seq OWNER TO rlllok;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rlllok
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: customers_videocards; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.customers_videocards (
    customer_id integer NOT NULL,
    video_card_id integer NOT NULL,
    buy_data timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    amount integer NOT NULL
);


ALTER TABLE public.customers_videocards OWNER TO rlllok;

--
-- Name: manufacturers; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.manufacturers (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.manufacturers OWNER TO rlllok;

--
-- Name: manufacturers_id_seq; Type: SEQUENCE; Schema: public; Owner: rlllok
--

CREATE SEQUENCE public.manufacturers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manufacturers_id_seq OWNER TO rlllok;

--
-- Name: manufacturers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rlllok
--

ALTER SEQUENCE public.manufacturers_id_seq OWNED BY public.manufacturers.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.vendors (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.vendors OWNER TO rlllok;

--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: rlllok
--

CREATE SEQUENCE public.vendors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vendors_id_seq OWNER TO rlllok;

--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rlllok
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: vendors_videocards; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.vendors_videocards (
    vendor_id integer NOT NULL,
    video_card_id integer NOT NULL
);


ALTER TABLE public.vendors_videocards OWNER TO rlllok;

--
-- Name: video_cards; Type: TABLE; Schema: public; Owner: rlllok
--

CREATE TABLE public.video_cards (
    id integer NOT NULL,
    name character varying NOT NULL,
    manufacturer_id integer NOT NULL,
    ram integer NOT NULL,
    core_clock integer NOT NULL,
    memory_bus_width integer NOT NULL,
    price numeric NOT NULL,
    in_stock integer NOT NULL
);


ALTER TABLE public.video_cards OWNER TO rlllok;

--
-- Name: video_cards_id_seq; Type: SEQUENCE; Schema: public; Owner: rlllok
--

CREATE SEQUENCE public.video_cards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_cards_id_seq OWNER TO rlllok;

--
-- Name: video_cards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rlllok
--

ALTER SEQUENCE public.video_cards_id_seq OWNED BY public.video_cards.id;


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: manufacturers id; Type: DEFAULT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.manufacturers ALTER COLUMN id SET DEFAULT nextval('public.manufacturers_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Name: video_cards id; Type: DEFAULT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.video_cards ALTER COLUMN id SET DEFAULT nextval('public.video_cards_id_seq'::regclass);


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.customers (id, name, account_balance) FROM stdin;
\.
COPY public.customers (id, name, account_balance) FROM '$$PATH$$/2992.dat';

--
-- Data for Name: customers_videocards; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.customers_videocards (customer_id, video_card_id, buy_data, amount) FROM stdin;
\.
COPY public.customers_videocards (customer_id, video_card_id, buy_data, amount) FROM '$$PATH$$/2993.dat';

--
-- Data for Name: manufacturers; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.manufacturers (id, name) FROM stdin;
\.
COPY public.manufacturers (id, name) FROM '$$PATH$$/2988.dat';

--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.vendors (id, name) FROM stdin;
\.
COPY public.vendors (id, name) FROM '$$PATH$$/2995.dat';

--
-- Data for Name: vendors_videocards; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.vendors_videocards (vendor_id, video_card_id) FROM stdin;
\.
COPY public.vendors_videocards (vendor_id, video_card_id) FROM '$$PATH$$/2996.dat';

--
-- Data for Name: video_cards; Type: TABLE DATA; Schema: public; Owner: rlllok
--

COPY public.video_cards (id, name, manufacturer_id, ram, core_clock, memory_bus_width, price, in_stock) FROM stdin;
\.
COPY public.video_cards (id, name, manufacturer_id, ram, core_clock, memory_bus_width, price, in_stock) FROM '$$PATH$$/2990.dat';

--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rlllok
--

SELECT pg_catalog.setval('public.customers_id_seq', 2, true);


--
-- Name: manufacturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rlllok
--

SELECT pg_catalog.setval('public.manufacturers_id_seq', 2, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rlllok
--

SELECT pg_catalog.setval('public.vendors_id_seq', 4, true);


--
-- Name: video_cards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rlllok
--

SELECT pg_catalog.setval('public.video_cards_id_seq', 5, true);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: manufacturers manufacturers_name_key; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.manufacturers
    ADD CONSTRAINT manufacturers_name_key UNIQUE (name);


--
-- Name: manufacturers manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.manufacturers
    ADD CONSTRAINT manufacturers_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_name_key; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_name_key UNIQUE (name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: vendors_videocards vendors_videocards_vendor_id_video_card_id_key; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors_videocards
    ADD CONSTRAINT vendors_videocards_vendor_id_video_card_id_key UNIQUE (vendor_id, video_card_id);


--
-- Name: video_cards video_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.video_cards
    ADD CONSTRAINT video_cards_pkey PRIMARY KEY (id);


--
-- Name: customers_videocards customers_videocards_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.customers_videocards
    ADD CONSTRAINT customers_videocards_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: customers_videocards customers_videocards_video_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.customers_videocards
    ADD CONSTRAINT customers_videocards_video_card_id_fkey FOREIGN KEY (video_card_id) REFERENCES public.video_cards(id) ON DELETE CASCADE;


--
-- Name: vendors_videocards vendors_videocards_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors_videocards
    ADD CONSTRAINT vendors_videocards_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendors_videocards vendors_videocards_video_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.vendors_videocards
    ADD CONSTRAINT vendors_videocards_video_card_id_fkey FOREIGN KEY (video_card_id) REFERENCES public.video_cards(id) ON DELETE CASCADE;


--
-- Name: video_cards video_cards_manufacturer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rlllok
--

ALTER TABLE ONLY public.video_cards
    ADD CONSTRAINT video_cards_manufacturer_id_fkey FOREIGN KEY (manufacturer_id) REFERENCES public.manufacturers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

