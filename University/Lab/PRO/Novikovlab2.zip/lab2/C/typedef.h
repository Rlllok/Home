#pragma once

void printMatrix(int** , const int, const int);
int lastMaxInColumnPosition(int** , const int, const int, const int);
void randomMatrix(int** , const int, const int);
void sortedMatrix(int** , const int , const int );
